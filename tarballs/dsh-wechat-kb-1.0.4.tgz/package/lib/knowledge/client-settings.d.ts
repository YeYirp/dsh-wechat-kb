export declare const SETTINGS_ENDPOINT = "/api/project-knowledge-review/settings";
export declare const KNOWLEDGE_ENDPOINT = "/api/project-knowledge-review/knowledge";
export interface KnowledgeSettingsView {
    enabled: boolean;
    answerPolicy: 'strict' | 'reference';
    localStorePath: string;
    projectName: string;
    requestTimeoutMs: number;
    ocrEnabled: boolean;
    ocrBaseUrl: string;
    ocrModel: string;
    ocrApiKeyEnv: string;
    asrEnabled: boolean;
    asrBaseUrl: string;
    asrModel: string;
    asrApiKeyEnv: string;
}
export interface SettingsEnvelope {
    ok: boolean;
    value?: KnowledgeSettingsView;
    revision?: number;
    writable?: boolean;
    message?: string;
}
